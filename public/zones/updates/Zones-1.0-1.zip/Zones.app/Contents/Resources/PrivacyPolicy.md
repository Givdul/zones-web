# Privacy Policy

Zones stores app preferences and layout choices locally on your Mac so the app can remember window-zoning settings between launches.

## Data Collection

- Zones does not include third-party analytics or advertising SDKs.
- Zones does not transmit your saved layouts or Accessibility state to a backend.

## Distribution

Zones is distributed as a free direct download. The app does not include in-app purchases, subscriptions, account sign-in, entitlement checks, or payment processing.

Downloads may be delivered through Polar as a free product so the release archive can be hosted securely and download/order statistics can be measured. Polar may process the information needed to provide that download, such as the checkout/download request and email address if collected by the download flow. This distribution metadata is not used by the app and is separate from app preferences stored on your Mac.

## Support

If you need help with the app or have privacy questions, visit `https://apps.givdul.com/zones/support` or contact `support@givdul.com`.
